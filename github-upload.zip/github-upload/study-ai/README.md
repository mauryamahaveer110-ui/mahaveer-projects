# Study AI for Class 10–12 Students

A terminal-based study chatbot. Choose your class and subject, then ask a doubt, read revision notes, or take a quiz.

## Run

```bash
python3 study_chatbot.py
```

## Files

- `study_chatbot.py` — main study chatbot (Class 10: Hindi, English, Maths, Science, Social Science; Classes 11–12: Physics, Chemistry, Maths, Biology, English)
- `chatbot.py` — simple rule-based chatbot (my first chatbot)
