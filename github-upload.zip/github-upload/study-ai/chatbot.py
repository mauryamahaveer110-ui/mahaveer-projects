# Simple AI Chatbot - made in VS Code
# No API key needed. Just run it with Python.

print("Hello! I am your chatbot. Type 'bye' to stop.")

while True:
    user = input("You: ").lower().strip()

    if user == "" :
        print("Bot: Please say something!")
        continue

    if user in ["bye", "exit", "quit"]:
        print("Bot: Goodbye! See you soon.")
        break

    elif "hello" in user or "hi" in user or "hey" in user:
        print("Bot: Hello! How can I help you today?")

    elif "your name" in user:
        print("Bot: My name is ChatBot. I was made in VS Code!")

    elif "how are you" in user:
        print("Bot: I am doing great! How are you?")

    elif "help" in user:
        print("Bot: You can ask me my name, say hello, or ask how I am.")

    elif "thank" in user:
        print("Bot: You're welcome!")

    else:
        print("Bot: That's interesting! Tell me more about that.")
