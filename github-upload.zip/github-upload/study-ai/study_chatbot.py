# Study Chatbot for Class 10, 11 and 12 - no API key needed
# Run on Mac with:  python3 study_chatbot.py
# Type 'bye' at any menu to stop. Type 'back' to go to the previous menu.

CLASSES = {
    "10": ["Hindi", "English", "Maths", "Science", "Social Science"],
    "11": ["Physics", "Chemistry", "Maths", "Biology", "English"],
    "12": ["Physics", "Chemistry", "Maths", "Biology", "English"],
}

# Short, simple revision notes. These are starter examples, not the full NCERT book.
# Add your own topics here in the same style: "topic keyword": "simple explanation"
NOTES = {
    "Maths": [
        "Maths: Practice one formula daily, then solve 5 questions on it.",
        "Maths: First write what is given, what is asked, then choose the formula.",
        "Maths: Check your answer at the end - does the unit and size make sense?",
    ],
    "Science": [
        "Science: Learn one concept with one daily-life example, not only the definition.",
        "Science: Draw the diagram, label it, then write 3 lines about it.",
        "Science: Revise formulas and reactions in short daily rounds, not in one long sitting.",
    ],
    "Physics": [
        "Physics: Write the formula, put the values with units, then calculate step by step.",
        "Physics: For numericals, first list given data, then find the right formula.",
        "Physics: Units matter - metre, second, newton, joule. Wrong unit = wrong answer.",
    ],
    "Chemistry": [
        "Chemistry: Learn reactions by balancing them yourself, not by only reading.",
        "Chemistry: Make a small table: reaction, reactants, products, and one use.",
        "Chemistry: Revise the periodic table trends in short, regular rounds.",
    ],
    "Biology": [
        "Biology: Learn with diagrams - draw, label, then explain in your own words.",
        "Biology: Make short notes: term, one-line meaning, one example.",
        "Biology: Revise diagrams and definitions together, not only definitions.",
    ],
    "English": [
        "English: Read the lesson once for story, once for difficult words.",
        "English: For writing, plan 3 points first, then write in simple sentences.",
        "English: Learn new words with one sentence of your own for each word.",
    ],
    "Hindi": [
        "Hindi: Path ko ek baar kahani ke liye padho, phir kathin shabdon ke liye.",
        "Hindi: Uttar likhne se pehle 3 points socho, phir saral vakyon me likho.",
        "Hindi: Sandhi, samas aur alankar ke ek-ek example roz yaad karo.",
    ],
    "Social Science": [
        "Social Science: Learn history as a story - kab, kahan, kaun, kyun.",
        "Social Science: For geography, learn with maps and diagrams.",
        "Social Science: For civics and economics, learn one definition + one example.",
    ],
}

# Two starter quiz questions per subject. Add more in the same format.
QUIZZES = {
    "Maths": [
        ("What is 15 x 4?", "60"),
        ("What is the square root of 144?", "12"),
    ],
    "Science": [
        ("Which gas do plants take in for photosynthesis?", "carbon dioxide"),
        ("What is the chemical symbol for water?", "h2o"),
    ],
    "Physics": [
        ("What is the SI unit of force?", "newton"),
        ("What is the speed of light in vacuum, approximately, in km/s?", "300000"),
    ],
    "Chemistry": [
        ("What is the chemical symbol for sodium?", "na"),
        ("What is H2SO4 commonly called?", "sulphuric acid"),
    ],
    "Biology": [
        ("Which organ pumps blood in the human body?", "heart"),
        ("Which part of the plant makes food?", "leaf"),
    ],
    "English": [
        ("What is the past tense of 'go'?", "went"),
        ("Choose the correct spelling: receive or recieve?", "receive"),
    ],
    "Hindi": [
        ("Hindi me 'book' ko kya kehte hain?", "pustak"),
        ("Hindi me 'school' ko kya kehte hain?", "vidyalaya"),
    ],
    "Social Science": [
        ("Who was the first President of India?", "rajendra prasad"),
        ("What is the capital of India?", "new delhi"),
    ],
}


def ask(prompt):
    return input(prompt).strip()


def show_notes(subject):
    print(f"\n--- {subject} revision notes ---")
    for line in NOTES.get(subject, ["Start with one chapter, make short notes, and revise daily."]):
        print("- " + line)


def run_quiz(subject):
    questions = QUIZZES.get(subject, [])
    if not questions:
        print("Quiz for this subject is coming soon. Try notes or doubt mode.")
        return
    score = 0
    print(f"\n--- {subject} quiz: {len(questions)} questions ---")
    for question, answer in questions:
        reply = ask(question + " ").lower().strip()
        if reply in ("bye", "back"):
            print("Quiz stopped.")
            return
        if reply == answer:
            print("Correct! Very good.")
            score += 1
        else:
            print(f"Not quite. Correct answer: {answer}")
    print(f"Your score: {score}/{len(questions)}")


def doubt_mode(subject):
    question = ask("\nApna doubt likho (example: formula, diagram, revision): ").lower()
    if question in ("bye", "back"):
        return
    if "formula" in question:
        print("Tip: Formula ko pehle likho, phir values dalo, phir step by step solve karo.")
    elif "diagram" in question:
        print("Tip: Diagram banao, label karo, phir uske baare me 3 lines apne shabdon me likho.")
    elif "revision" in question or "revise" in question:
        print("Tip: Chhote-chhote rounds me revise karo - roz thoda, ek din me sab kuch nahi.")
    else:
        print(f"{subject} ke liye: pehle chapter ka main concept ek line me likho,")
        print("phir ek example do, phir us par 2 practice questions solve karo.")
        print("Agar jawab galat lage, to NCERT book se ek baar check karo - ye starter version hai.")


def main():
    print("Hello! I am your Study Chatbot.")
    print("Class 10, 11 and 12 ke sab subjects ke liye - no API key needed.")
    print("Type 'bye' to stop, 'back' to go back.\n")

    while True:
        print("Choose your class: 10, 11, 12")
        class_choice = ask("Class: ").lower()
        if class_choice == "bye":
            print("Bot: Goodbye! Keep studying a little every day.")
            break
        if class_choice not in CLASSES:
            print("Please choose 10, 11 or 12.\n")
            continue

        subjects = CLASSES[class_choice]
        while True:
            print(f"\nClass {class_choice} subjects:")
            for i, subject in enumerate(subjects, 1):
                print(f"  {i}. {subject}")
            subject_choice = ask("Subject number ya naam: ").lower()
            if subject_choice == "bye":
                print("Bot: Goodbye! Keep studying a little every day.")
                return
            if subject_choice == "back":
                break
            # Accept both a number (5) and a name (english / English)
            subject_map = {s.lower(): s for s in subjects}
            if subject_choice.isdigit() and 1 <= int(subject_choice) <= len(subjects):
                subject = subjects[int(subject_choice) - 1]
            elif subject_choice in subject_map:
                subject = subject_map[subject_choice]
            else:
                print("Please choose a valid subject number ya naam.")
                continue

            print("\nWhat do you want to do?")
            print("  1. Ask a doubt")
            print("  2. Revision notes")
            print("  3. Quiz")
            mode = ask("Choose 1, 2 or 3 (ya doubt / notes / quiz likho): ").lower()
            if mode == "bye":
                print("Bot: Goodbye! Keep studying a little every day.")
                return
            if mode == "back":
                continue
            if mode in ("1", "doubt", "ask a doubt", "ask doubt"):
                doubt_mode(subject)
            elif mode in ("2", "notes", "revision notes", "revision", "note"):
                show_notes(subject)
            elif mode in ("3", "quiz", "test"):
                run_quiz(subject)
            else:
                print("Please choose 1, 2 or 3, ya doubt / notes / quiz likho.")
            print("\nWapas class menu par ja rahe hain...\n")
            break


if __name__ == "__main__":
    main()
