#!/usr/bin/env python3
"""
CODE HERO - Mahaveer's Coding Game
----------------------------------
A beginner Python adventure game for MacBook.
Run it with:  python3 coding_game.py

How it works:
- You are Code Hero. Each level is a locked door.
- Answer the Python question correctly to open the door and earn 10 points.
- Wrong answer = lose 1 life. You have 3 lives.
- Type 'hint' to get a hint (costs 2 points, only once per level).
- Finish all 10 levels to win the game!
"""

import sys

LEVELS = [
    {
        "title": "Level 1 - The First Door",
        "story": "A stone door blocks your way. On it is written:",
        "code": 'print("Hello")',
        "question": "What will this code print on the screen?",
        "answer": "hello",
        "hint": "print() shows exactly what is inside the quotes.",
    },
    {
        "title": "Level 2 - The Number Lock",
        "story": "A lock asks for a secret number:",
        "code": "x = 5 + 3\nprint(x)",
        "question": "What number will be printed? (type only the number)",
        "answer": "8",
        "hint": "5 + 3 = ?",
    },
    {
        "title": "Level 3 - The Name Gate",
        "story": "The gatekeeper asks your name in code:",
        "code": 'name = "Mahaveer"\nprint("Hello " + name)',
        "question": "What will be printed? (type it exactly, with the space)",
        "answer": "hello mahaveer",
        "hint": '"Hello " + "Mahaveer" joins the two words together.',
    },
    {
        "title": "Level 4 - The If-Else Bridge",
        "story": "A bridge appears only if your answer is right:",
        "code": "age = 18\nif age >= 18:\n    print('Adult')\nelse:\n    print('Child')",
        "question": "What will be printed: Adult or Child?",
        "answer": "adult",
        "hint": "18 >= 18 is True, so the 'if' part runs.",
    },
    {
        "title": "Level 5 - The Loop Stairs",
        "story": "Stairs appear one by one. Count them:",
        "code": "for i in range(3):\n    print('Step')",
        "question": "How many times will 'Step' be printed? (type only the number)",
        "answer": "3",
        "hint": "range(3) gives 0, 1, 2 - that is 3 times.",
    },
    {
        "title": "Level 6 - The List Chest",
        "story": "A treasure chest has a list inside:",
        "code": "fruits = ['apple', 'banana', 'mango']\nprint(fruits[1])",
        "question": "Which fruit will be printed?",
        "answer": "banana",
        "hint": "Counting in Python starts from 0, so [1] is the second item.",
    },
    {
        "title": "Level 7 - The While River",
        "story": "You must cross the river by counting:",
        "code": "n = 1\nwhile n < 4:\n    n = n + 1\nprint(n)",
        "question": "What number will be printed at the end? (type only the number)",
        "answer": "4",
        "hint": "The loop stops when n is no longer less than 4.",
    },
    {
        "title": "Level 8 - The Function Key",
        "story": "A magic key is made by a function:",
        "code": "def add(a, b):\n    return a + b\nprint(add(4, 5))",
        "question": "What number will be printed? (type only the number)",
        "answer": "9",
        "hint": "add(4, 5) returns 4 + 5.",
    },
    {
        "title": "Level 9 - The String Spell",
        "story": "A spell is written in a string:",
        "code": 'word = "Python"\nprint(len(word))',
        "question": "What number will be printed? (type only the number)",
        "answer": "6",
        "hint": "len() counts the letters. P-y-t-h-o-n = ?",
    },
    {
        "title": "Level 10 - The Final Boss",
        "story": "The Final Boss guards the treasure. One last question:",
        "code": "x = 10\nif x % 2 == 0:\n    print('Even')\nelse:\n    print('Odd')",
        "question": "What will be printed: Even or Odd?",
        "answer": "even",
        "hint": "10 % 2 = 0, so 10 is divisible by 2.",
    },
]


def ask(question, answer, hint):
    """Ask one question. Returns points earned (10, 8 with hint, or 0)."""
    used_hint = False
    while True:
        reply = input("\nYour answer (or type 'hint'): ").strip().lower()
        if reply == "hint":
            if used_hint:
                print("Hint already used for this level.")
            else:
                print("Hint:", hint)
                used_hint = True
            continue
        if reply == answer:
            points = 8 if used_hint else 10
            print("Correct! Door opens!  +{} points".format(points))
            return points
        print("Wrong answer. Try again! (type 'hint' if you are stuck)")
        return 0


def play():
    print("\n" + "=" * 50)
    print("  CODE HERO - Mahaveer's Coding Adventure")
    print("=" * 50)
    print("You have 3 lives. Each correct answer = 10 points.")
    print("Hint costs 2 points. Finish all 10 levels to win!")
    print("=" * 50)

    score = 0
    lives = 3

    for level in LEVELS:
        print("\n--- " + level["title"] + " ---")
        print(level["story"])
        print("\n" + level["code"] + "\n")
        print("Q: " + level["question"])

        points = ask(level["question"], level["answer"], level["hint"])
        if points == 0:
            lives -= 1
            print("You lost 1 life. Lives left:", lives)
            if lives == 0:
                print("\nGAME OVER! You ran out of lives.")
                print("Your score:", score, "points")
                print("Try again - practice makes you stronger!")
                return
        else:
            score += points
        print("Score:", score, "| Lives:", lives)

    print("\n" + "=" * 50)
    print("  YOU WIN! You finished all 10 levels!")
    print("  Final Score:", score, "out of 100")
    if score == 100:
        print("  PERFECT SCORE! You are a true Code Hero!")
    elif score >= 70:
        print("  Great job, Code Hero!")
    else:
        print("  Good job! Play again to beat your score!")
    print("=" * 50)


def how_to_play():
    print("\nHOW TO PLAY:")
    print("1. Run the game with:  python3 coding_game.py")
    print("2. Choose 1 to Play.")
    print("3. Read the Python code shown in each level.")
    print("4. Type the answer (the output of the code) and press Enter.")
    print("5. Type 'hint' if you are stuck (costs 2 points).")
    print("6. You have 3 lives. Wrong answer = lose 1 life.")
    print("7. Finish all 10 levels to win!")


def main():
    while True:
        print("\n===== CODE HERO =====")
        print("1. Play Game")
        print("2. How to Play")
        print("3. Quit")
        choice = input("Choose 1, 2 or 3: ").strip()
        if choice == "1":
            play()
        elif choice == "2":
            how_to_play()
        elif choice == "3":
            print("Thanks for playing, Code Hero! Bye!")
            sys.exit(0)
        else:
            print("Please type 1, 2 or 3.")


if __name__ == "__main__":
    main()
