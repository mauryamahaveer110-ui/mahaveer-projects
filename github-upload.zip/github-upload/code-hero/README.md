# CODE HERO

A terminal coding-practice game for Python beginners.

## Run

```bash
python3 coding_game.py
```

## How to play

- 10 levels: print, variables, if-else, loops, lists, while, functions, strings, and a final boss
- Correct answer: +10 points
- Wrong answer: lose 1 of 3 lives
- Type `hint` for a hint (that level scores 8 instead of 10)
- Score 100/100 for a perfect run
