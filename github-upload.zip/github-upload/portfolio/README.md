# Portfolio Website

My personal portfolio — dark red/black design with animated particles, a typing intro, and a building animation.

## Run

Open `mahaveer-portfolio.html` in a browser, or in VS Code with the Live Server extension (right-click → Open with Live Server).

No Node, Python or server needed. Internet is needed only for Google Fonts.

## Contact

- LinkedIn: https://www.linkedin.com/in/mahaveer-maurya-7bb553262
