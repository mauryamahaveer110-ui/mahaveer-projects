# Mahaveer Maurya — Projects

My coding projects, built while studying BCA (First Semester) at Rawal Institute of Technology, MDU Rohtak.

## Projects

| Folder | Project | Tech |
| --- | --- | --- |
| `mahaveer-ai/` | MAHAVEER AI — web AI chat app | Node.js, Express, OpenAI |
| `study-ai/` | Study AI for Class 10–12 students | Python |
| `code-hero/` | CODE HERO — coding practice game | Python |
| `portfolio/` | Personal portfolio website | HTML, CSS, JavaScript |
| `rubber-die-3d-scanner/` | Rubber Die 3D Scanner System (project plan) | 3D scanning, Python |

## How to run

- **MAHAVEER AI:** see `mahaveer-ai/README.md`
- **Study AI:** `python3 study-ai/study_chatbot.py`
- **CODE HERO:** `python3 code-hero/coding_game.py`
- **Portfolio:** open `portfolio/mahaveer-portfolio.html` in a browser (or with Live Server in VS Code)

## Note on API keys

Never commit a real API key. Copy `.env.example` to `.env` and put your own key there. `.env` is ignored by git.
