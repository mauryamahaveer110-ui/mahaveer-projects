# Rubber Die 3D Scanner System

A college project that also helps my father's rubber-line work: scan a physical rubber sample or iron die, and get a measured 3D model on a laptop with full sizes (diameter, radius, height/thickness, cutout, screw holes) in mm and micrometres — ready as a die specification.

It also works as a pre-dispatch quality check: scan a sample piece, compare it with the master design, and get PASS or FAIL before dispatch, so a defective piece is caught early.

## Plan (scan → measure → report)

1. Scan the physical rubber/die directly with a 3D scanner (no photo — photos have no role here)
2. Clean and align the mesh, segment the outer shape, cutout, zigzag slit and screw holes
3. Measure every feature, with a final human check
4. Output: measured 3D model + die spec sheet in mm and micrometres

## Sampling QC

Only sample pieces are scanned: the first piece off the machine, one in the middle, and the last piece before dispatch.

## Status

Planning stage — scanner choice and pilot testing at my father's company are the next steps. No code in this folder yet.
