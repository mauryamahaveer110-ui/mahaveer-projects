require("dotenv").config();

const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json({ limit: "1mb" }));

// Serve frontend files (index.html, script.js, style.css)
app.use(express.static(__dirname));

// OpenAI client - key is read from .env, never written in this file
const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// Status route
app.get("/api/status", (req, res) => {
    res.json({
        status: "success",
        message: "MAHAVEER AI is running"
    });
});

// AI chat route
app.post("/api/chat", async (req, res) => {
    try {
        const { message, history = [] } = req.body;

        if (
            typeof message !== "string" ||
            !message.trim()
        ) {
            return res.status(400).json({
                error: "Please type a message first."
            });
        }

        if (!process.env.OPENAI_API_KEY) {
            return res.status(503).json({
                error: "AI service is not configured. Add OPENAI_API_KEY to your .env file."
            });
        }

        // Keep only recent conversation messages
        const safeHistory = Array.isArray(history)
            ? history
                .filter(item =>
                    item &&
                    ["user", "assistant"].includes(item.role) &&
                    typeof item.content === "string"
                )
                .slice(-10)
            : [];

        const conversation = [
            {
                role: "system",
                content:
                    "You are MAHAVEER AI, a friendly, helpful and intelligent AI assistant. Give clear and accurate answers. Use simple language when appropriate."
            },
            ...safeHistory.map(item => ({
                role: item.role,
                content: item.content.slice(0, 4000)
            })),
            {
                role: "user",
                content: message.trim()
            }
        ];

        // NOTE: Use a model you actually have access to.
        // gpt-4o-mini is cheap and good for testing.
        // If you have access to a newer model, change this line only.
        const response = await client.responses.create({
            model: "gpt-4o-mini",
            input: conversation
        });

        res.json({
            reply: response.output_text ||
                "Sorry, I could not generate a reply."
        });

    } catch (error) {
        console.error("AI error:", error);

        res.status(500).json({
            error: "Something went wrong while talking to the AI. Check the server console and your model / API key."
        });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(
        `MAHAVEER AI running at http://localhost:${PORT}`
    );
});
