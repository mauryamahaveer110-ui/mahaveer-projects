# MAHAVEER AI

A web AI chat app built with Node.js, Express and the OpenAI API.

## Setup

```bash
npm install
cp .env.example .env
# open .env and paste your own OpenAI API key
npm start
```

Then open http://localhost:3000 in your browser.

## Files

- `server.js` — Express server + OpenAI call
- `index.html` — chat page
- `script.js` / `style.css` — frontend logic and styling
- `.env.example` — blank key template (never commit a real `.env`)
