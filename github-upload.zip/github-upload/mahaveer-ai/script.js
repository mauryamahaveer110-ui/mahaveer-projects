const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const clearChat = document.getElementById("clearChat");
const newChat = document.getElementById("newChat");

// LLM ko pichhle messages yaad rakhne ke liye
const history = [];

function addMessage(text, sender) {
    const message = document.createElement("div");
    message.className = "message " + sender;

    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = sender === "bot" ? "AI" : "YOU";

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    message.appendChild(avatar);
    message.appendChild(bubble);
    chatBox.appendChild(message);

    chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendMessage() {
    const text = userInput.value.trim();

    if (!text || sendBtn.disabled) {
        return;
    }

    addMessage(text, "user");
    userInput.value = "";
    sendBtn.disabled = true;

    const typing = document.createElement("div");
    typing.className = "message bot";
    typing.id = "typing";

    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "AI";

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = "Typing...";

    typing.appendChild(avatar);
    typing.appendChild(bubble);
    chatBox.appendChild(typing);
    chatBox.scrollTop = chatBox.scrollHeight;

    try {
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                message: text,
                history: history
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "AI request failed.");
        }

        const reply = data.reply || "AI se response nahi mila.";

        history.push(
            { role: "user", content: text },
            { role: "assistant", content: reply }
        );

        addMessage(reply, "bot");
    } catch (error) {
        addMessage("Error: " + error.message, "bot");
    } finally {
        typing.remove();
        sendBtn.disabled = false;
        userInput.focus();
    }
}

function resetChat() {
    chatBox.innerHTML = "";
    history.length = 0;

    addMessage(
        "Hello Mahaveer! 👋 Welcome back. How can I help you?",
        "bot"
    );
}

sendBtn.addEventListener("click", sendMessage);

userInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        sendMessage();
    }
});

clearChat.addEventListener("click", resetChat);
newChat.addEventListener("click", resetChat);